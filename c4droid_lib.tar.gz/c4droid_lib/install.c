#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <unistd.h>

int main() {
	char path_lib[256]={};
	#if defined (__arm64__)|| defined (__aarch64__)
    printf("你的系统是arm64位: 64-bit [__arm64__ arch]\n");
    strcpy(path_lib,"cp -r src/* ");
    strcat(path_lib,"/data/user/0/com.n0n3m4.droidc/files/gcc/aarch64-linux-android/");
    #elif defined(__arm__)
    printf("暂不支持\n");
    return 0;
    #endif
    puts("开始安装");
    puts(path_lib);
    system(path_lib);
    puts("安装成功");
    return 0;
}